
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>

    <?php include_once ('./header.php');?>

</head>

<body>
<div>
 	   <h3 style="color: red; " align="center">Add Product</h3>
 </div>

 <form action="../Controller/createProduct.php" method="POST" enctype="multipart/form-data">
  <label for="Name">Name:</label><br>
  <input type="text" id="Name" name="Name"><br>
  <label for="Buying_Price">Buying Price:</label><br>
  <input type="text" id="Buying_Price" name="Buying_Price"><br>
  <label for="Selling_Price">Selling Price:</label><br>
  <input type="text" id="Selling_Price" name="Selling_Price"><hr><br>
  
  <input type="checkbox" id="chk" name="display">
    <label for="chk"> Display </label><hr>
    <br>
  <input type="submit" name="createProduct" value="Save"> 
  <input type="reset"> 
</form> 
</body>
</html>

<?php 
    include ('./footer.php');
?>