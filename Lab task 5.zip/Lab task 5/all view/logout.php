<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>
	<?php include_once '../Controller/logout-check.php' ?>
</head>
<body>

</body>
</html>