<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>footer</title>
</head>
<body>
	<footer style="border: px solid ; width: 100%; height: 50px; background-color: white; ">
	<p align ="center" style="color: gray;"> Succesfull & final;
	 2021| Lab Task 5
	</p>
	 </footer>


</body>
</html>